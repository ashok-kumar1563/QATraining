package DAY6;

import java.util.ArrayList;

public class pgm3 {
	ArrayList<Student> std_al=new ArrayList<Student>();
	public void create_al()
	{
		Student s1=new Student("Ramesh",101,80,90);
		Student s2=new Student("Ramesh1",102,85,95);
		std_al.add(s1);
		std_al.add(s2);
		
		
	}
	public void display()
	{
		for(Student s: std_al)
		{
			System.out.println("name:"+s.name);
			System.out.println("Rollno:"+s.rollno);
			System.out.println("m1:"+s.m1);
			System.out.println("m2:"+s.m2);
			System.out.println("Average "+s.avg);
		} 
			
	} 
	
		

	public static void main(String[] args) {
		
pgm3 p1=new pgm3();
p1.create_al();
p1.display();


	}

}
