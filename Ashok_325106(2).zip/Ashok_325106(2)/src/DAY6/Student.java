package DAY6;

public class Student {

	public String name;
    	public	int rollno;
    	 public int m1;
    	public	float avg;
	    public int m2;
	 
	public void average()
	{
		  this.avg=((m1+m2)/2);
	}
	 
	   public Student(String name, int rollno, int m1, int m2) {
			// TODO Auto-generated constructor stub
		   this.name=name;
			this.rollno= rollno;
			this.m1=m1;
			this.m2=m2;
			this.average();
		}
}
