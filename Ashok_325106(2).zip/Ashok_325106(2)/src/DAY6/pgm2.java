package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ArrayList<String> str_al=new ArrayList<String>();
    str_al.add("asf");
    str_al.add("Rakesh");
    str_al.add("Himanshu");
    str_al.add("Suresh");
    System.out.println("Before Insertion :"+str_al);
    str_al.add("Priya");
    System.out.println("after Insertion :"+str_al);
    str_al.remove(2);
    str_al.add(2, "Ashok");
    System.out.println("At last :"+str_al);

	}

}
