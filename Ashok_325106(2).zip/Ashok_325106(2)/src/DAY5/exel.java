package DAY5;



public class exel {

	public static void main(String[] args) {
		
		excel_opr excel=new excel_opr();
		for(int i=1;i<=2;i++)
		{
		Student s1=excel.read_excel(i);
		s1.average();
		excel.write_excel(s1,i);
		}
		

	}

}
