package DAY5;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int a[]= {1,2,3};
			int b=a[2];
		    System.out.println(b);
		int n=10,b1=0,c;
		c=n/b1;
		System.out.println(c);
		
		}
		catch(ArithmeticException e)
		{
			System.out.println("In ArithmeticException catch block");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("In ArrayIndexOutOfBoundsException catch block");
		}
		
		System.out.println("out of catch block");
		
	}

}
