package DAY1;
import java.util.*;
public class pgm10 {

	public static void main(String[] args) {
	
Scanner sc=new Scanner(System.in);
System.out.println("enter the character");
char c=sc.next().charAt(0);
if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
	System.out.println("character is vowel");
else
	System.out.println("character is consonents");
	}

}
