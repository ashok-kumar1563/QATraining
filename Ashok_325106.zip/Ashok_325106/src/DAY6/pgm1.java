package DAY6;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String a[]= {"Noida","Globallogic","Delhi"};
       for(String s:a)
	   System.out.println(s);
	}

}
