package DAY2;
import java.util.*;
public class pgm1 {
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		
		int s=sc.nextInt();
		switch(s)
		{
		case 2:
			System.out.println("two");
			break;
		case 5:
			System.out.println("five");
			break;
		case 9:
			System.out.println("nine");
		default :
			System.out.println("no match");
		}
		System.out.println("out of switch");
	}

}
