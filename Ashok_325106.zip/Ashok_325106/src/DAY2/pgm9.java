package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		int j=5,k=4;
		for(int i=1;i<=5;i++)
		{
			System.out.println(j +"*"+k+"="+j*k);
			j++;
			k=k+2;
		}

	}

}
