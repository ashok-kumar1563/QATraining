package assignment;

public class pgm2 {
	public static String [] extract_word(String str)
	{
		String a[]=new String[20];
		str=str.trim();
		int l=str.length();
		int index1=0,index2,j=0;
		for(int i=0;i<l-1;i++)
		{
			if(str.charAt(i)==' '&&str.charAt(i+1)!=' ')
			{
				index2=i;
				a[j++]=str.substring(index1,index2);
				index1=index2+1;
			}
		}
		a[j++]=str.substring(index1,l);
		
		return a;
		
	}
	public static void count_print(String words[])
	{
		int l=words.length;
	try {	
		for(int i=0;i<l;i++)
		{
			int count=0,l1;
			
			if(!words[i].equals(" "))
			{
			l1=words[i].length();
			for(int j=0;j<l1;j++)
				count++;
			if(count>5)
				System.out.println(words[i]);	
			}
		}
	}catch(Exception e)
	{ 
			
	}
	}
	

	public static void main(String[] args) {
		
       String a="Hello I am working at Global Logic";
       String arr[]=extract_word(a);
       count_print(arr);
	}

}
