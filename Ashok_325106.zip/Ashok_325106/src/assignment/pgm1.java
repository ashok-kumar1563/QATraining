package assignment;

public class pgm1 {

	public static void main(String[] args) {
		int arr1[]=new int[20];
		int j=0;
		for(int i=10;i<=30;i++)
		{
			if(i%3==0)
			{
				arr1[j]=i;
				j++;
			}
		}
		int arr2[]=new int[10];
		int k=0;
		for(int i=10;i<=30;i=i+5)
		{
			arr2[k]=i;
			k++;
		}
		for(int x=0;x<j;x++)
		{
			for(int y=0;y<k;y++)
			{
				int sum=arr1[x]+arr2[y];
				if(sum>30&&sum<40)
					System.out.println(arr1[x]+" + "+arr2[y]+" = "+sum);
			}
			
		}
		

	}

}
