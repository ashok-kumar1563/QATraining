package DAY4;

public class pgm5 {

	public int add(int x,int y)
	{
		int z=x+y;
		return z;
	}
	public float add(int a,int b,float c)
	{
		return a+b+c;
	}

}
