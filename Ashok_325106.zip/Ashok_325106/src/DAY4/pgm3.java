package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		String live="     I am working with global logic in noida";
		live=live.trim();
		int index1,index2,j=0;
		int l=live.length();
		String arr[]=new String[50];
		index1=0;
		for(int i=0;i<l-1;i++)
		{
			if(live.charAt(i)==' '&&live.charAt(i+1)!=' ')
			
            {
            	index2=i;
            	arr[j]=live.substring(index1,index2);
            	index1=index2+1;
            	j++;
            }
		}
		index2=live.length();
		arr[j++]=live.substring(index1,index2);
		
		for(int i=0;i<j;i++)
			System.out.println(arr[i]);

	}

}
