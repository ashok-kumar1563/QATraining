package DAY4;

public class Student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	public Student(int rollno,String name,int m1)
	{
		this.rollno=rollno;
		this.name=name;
		this.m1=m1;
		
	}
     public void display()
     {
    	 System.out.println("Name :"+this.name);
    	 System.out.println("Rollno:"+this.rollno);
    	 System.out.println("marks1: "+this.m1);
     }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student(10,"rakesh",85);
		Student s2=new Student(3,"ashok",87);
		Student s3=new Student(15,"kanika",89);
		s1.display();
		s2.display();
		s3.display();

		

	}

}
