package DAY4;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        pgm5 p1=new pgm5();
        int sum=p1.add(5, 10);
        System.out.println("First sum= "+sum);
        float s=p1.add(2,3,4.1f );
        System.out.println("Second sum= "+s);
	}

}
