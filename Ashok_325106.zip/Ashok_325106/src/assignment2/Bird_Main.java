package assignment2;

public class Bird_Main {

	public static void main(String[] args) {
		Parrot p1=new Parrot("Peeku","Green",1,2,2,10);
		Parrot p2=new Parrot("biti","lessGreen",1,2,2,10);
		Parrot p3=new Parrot("Bitu","DarkGreen",1,2,2,10);
		p1.display();
		p2.display();
		p3.display();
		p1.breathe();
		p1.parrot_habitat();
		p2.parrot_food();
		p3.imitate();
		Owl o1=new Owl("o1","Green",1,2,2);
		Owl o2=new Owl("o2","lessGreen",1,2,2);
		o1.display();
		o2.display();
		o1.owl_habitat();
		o2.owl_food();

	}

}
