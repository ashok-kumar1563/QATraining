package assignment2;

public class Student_main {

	public static void main(String[] args) {
		Student s[]=new Student[3];
		Student s1 = new Student(101,"Riya",55,80);
		Student s2=new Student(102,"Ashok",60,90);
		Student s3=new Student(101,"Gavrav",50,70);
		s[0]=s1;
		s[1]=s2;
		s[2]=s3;
     for(int i=0;i<3;i++)
     {
    	 if(s[i].avg>65)
    	 {
    		 System.out.println("Rollno : "+s[i].rollno+" Name : "+s[i].name+" java_marks : "+s[i].java+" Selenium_marks : "+s[i].selenium+" Average: "+s[i].avg);
    	 }
     }

	}

}
