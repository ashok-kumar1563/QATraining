package assignment2;

public class excel_main extends pgm3 {

	public static void main(String[] args) {
		pgm3 p1=new pgm3();
		p1.read_excel();
		p1.cal_price();
		p1.cal_Grade();
		p1.write_excel();

	}

}
