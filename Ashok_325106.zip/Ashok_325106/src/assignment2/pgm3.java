package assignment2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm3 {

	ArrayList<Product> al_p=new ArrayList<Product>();
	public void read_excel()
	{
	
		File f=new File("D:\\training\\Product.xlsx");
		try {
	        FileInputStream fis=new FileInputStream(f);
	        XSSFWorkbook wb=new XSSFWorkbook(fis);
	        XSSFSheet sh=wb.getSheet("Sheet1");
			for(int i=1;i<=3;i++)
			{
				Product p=new Product();
				XSSFRow r=sh.getRow(i);
				XSSFCell c1=r.getCell(0);
				p.p_id=(int)c1.getNumericCellValue();
				XSSFCell c2=r.getCell(1);
				p.p_name=c2.getStringCellValue();
				XSSFCell c3=r.getCell(2);
				p.per_unit_rate=(int)c3.getNumericCellValue();
				XSSFCell c4=r.getCell(3);
				p.units_purchased=(int)c4.getNumericCellValue();
				al_p.add(p);
				
			}
			
			for(Product p :al_p)
			{
				System.out.println(p.p_id);
				System.out.println(p.p_name);
				System.out.println(p.per_unit_rate);
				System.out.println(p.units_purchased);
			}
		   }
		catch(Exception e)
		{
			
		}
	}
	public void cal_price()
	{
		for(int i=0;i<=2;i++)
		{
			Product p=al_p.get(i);
			p.price=(p.per_unit_rate)*(p.units_purchased);
		}
	}
	public void cal_Grade()
	{
		for(int i=0;i<=2;i++)
		{
			Product p=al_p.get(i);
			if(p.price>=25000)
				p.p_grade="GradeB";
			else
				p.p_grade="GradeA";
		}
	}
	public void write_excel()
	{
		try {
			File f=new File("D:\\training\\Product.xlsx");
			 FileInputStream fis=new FileInputStream(f);
		        XSSFWorkbook wb=new XSSFWorkbook(fis);
		        XSSFSheet sh=wb.getSheet("Sheet1");
		        int row=1;
		        for(Product p:al_p)
		        {
		        XSSFRow r=sh.getRow(row);
		        XSSFCell c1=r.createCell(4);
		        c1.setCellValue(p.price);
		        XSSFCell c2=r.createCell(5);
		        c2.setCellValue(p.p_grade);
		        	row++;	
		        }
		    FileOutputStream fos=new FileOutputStream(f);
		    wb.write(fos);
			
		}
		catch(Exception e)
		{}
		
	}
	
}
