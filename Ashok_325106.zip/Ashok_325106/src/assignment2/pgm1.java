package assignment2;

import java.util.ArrayList;

public class pgm1 {
	
	String str="I have learnt loops,oops concept,inheritance,exception handling,arraylist and string handling";
	 public ArrayList<String> get_each_word(String str)
	 {
		 ArrayList<String> al_str=new ArrayList<String>();
		 int index1=0,index2;
		 for(int i=0;i<str.length();i++)
		 {
			 if(str.charAt(i)==' '||str.charAt(i)==',')
			 {
				 index2=i;
				 al_str.add(str.substring(index1,index2));
				 index1=index2+1;
			 }
		 }
		 al_str.add(str.substring(index1,str.length()));
		 return al_str;
	 }
	 public ArrayList<String> count_vowels(ArrayList<String> s)
	 {
		 ArrayList<String> al_str =new ArrayList<String>();
		 for(int i=0;i<s.size();i++)
		 {
			 String s1=s.get(i);
			 int count=0;
			 for(int j=0;j<s1.length();j++)
			 {
				if(s1.charAt(j)=='a'||s1.charAt(j)=='e'||s1.charAt(j)=='i'||s1.charAt(j)=='o'||s1.charAt(j)=='u')
					count++;
			 }
			 if(count>=3)
				 al_str.add(s1);
		 }
		 return al_str;
	 }
	
 
	public static void main(String[] args) {
		pgm1 p1=new pgm1();
		ArrayList<String> a1=p1.get_each_word(p1.str);
		ArrayList<String> a2=p1.count_vowels(a1);
		System.out.println("Words which have vowels more than 2 :");
		for(String s :a2)
			System.out.println(s);

	}

}
