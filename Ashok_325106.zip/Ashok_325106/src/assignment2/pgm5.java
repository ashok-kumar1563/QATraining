package assignment2;

public class pgm5 {
	boolean isArmstrong(int n)
	{
		int sum=0,rem=0,num=n;
		while(n!=0)
		{
			rem=n%10;
			sum=sum+rem*rem*rem;
			n=n/10;
		}
		if(num==sum)
			return true;
		else
			return false;
		
	}
	

	public static void main(String[] args) {
		pgm5 p=new pgm5();
   int arr[]=new int[5];
   int n=100,j=0;
   while(n<1000||j==5)
   {
	   if(p.isArmstrong(n))
	   {
		   arr[j++]=n;
	   }
		n++;   
   }
   for(int i=0;i<j;i++)
	   System.out.println(arr[i]+" ");
	}

}
