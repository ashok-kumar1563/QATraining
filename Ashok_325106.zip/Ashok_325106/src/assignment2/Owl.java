package assignment2;

public class Owl extends Bird {
	
	
	public void eySight()
	{
		System.out.println("Birds can see in night");
	}
	public void owl_habitat()
	{
		System.out.println("They are found in all region of world except polar region");
	}
	public void owl_food()
	{
		System.out.println("They eat sqireels and insects");
	}
	public Owl(String name,String Colour,int No_of_tails,int No_of_legs,int No_of_wings)
	{
	
		this.name=name;
		this.Colour=Colour;
		this.No_of_legs=No_of_legs;
		this.No_of_tails=No_of_tails;
		this.No_of_wings=No_of_wings;	
	}
	public void display()
	{
		
		System.out.println("Name: "+this.name+" Color: "+this.Colour+" No_of_legs :"+this.No_of_legs+" No_of_tails:"+this.No_of_tails+" No_of_wings: "+this.No_of_wings);
		
		
	}
	
}
