package assignment2;

public class Student {
	int rollno,java,selenium;
	String name;
	float avg;
	void average()
	{
		this.avg=(this.java+this.selenium)/2.0f;
	}
	public Student(int rollno,String name,int java,int selenium)
	{
		this.rollno=rollno;
		this.name=name;
		this.java=java;
		this.selenium=selenium;
		this.average();
	}

}
