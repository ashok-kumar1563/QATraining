package DAY10;

public class Table2 {
	int customer_id;
	String customer_name;

}
