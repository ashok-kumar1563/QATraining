package DAY10;

public class Table1 {

	int route_id;
	String from,to;
	int unit_price;
}
