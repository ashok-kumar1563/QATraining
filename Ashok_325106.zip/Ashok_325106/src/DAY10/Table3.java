package DAY10;

public class Table3 {
	int customer_id,route_id,no_of_ticket;

}
