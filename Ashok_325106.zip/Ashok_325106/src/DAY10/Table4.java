package DAY10;

public class Table4 {
	int customer_id,unit_price,no_of_tickets,price;
	String customer_name ,from,to;

}
