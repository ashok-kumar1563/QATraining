package DAY10;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_opr {
	ArrayList<Table1> al_t1=new ArrayList<Table1>();
	public  void read_excel1()
	{
		// TODO Auto-generated method stub
		
				File f=new File("C:\\Users\\ashok.kumar2\\Desktop\\Book4.xlsx");
				
				try {
					FileInputStream fis = new FileInputStream(f);
					XSSFWorkbook wb=new XSSFWorkbook(fis);
					
					XSSFSheet sh=wb.getSheet("Sheet1");
					for(int i=2;i<=3;i++)
					{		
					XSSFRow r=sh.getRow(i);
					Table1 t1=new Table1();
					XSSFCell c1=r.getCell(0);
					t1.route_id=(int)c1.getNumericCellValue();
					XSSFCell c2=r.getCell(1);
					t1.from=c2.getStringCellValue();
					XSSFCell c3=r.getCell(2);
					t1.to=c3.getStringCellValue();
					XSSFCell c4=r.getCell(3);
					t1.unit_price=(int)c4.getNumericCellValue();
					al_t1.add(t1);
					
					}
			} 
				
				catch (Exception e) 
				{
					// TODO Auto-generated catch block
					System.out.println(e);
					}
     for(Table1 t1:al_t1)
     {
    	 System.out.println(t1.route_id+" "+t1.from+" "+t1.to+" "+t1.unit_price);
     }
				}

	public static void main(String[] args) {
	excel_opr e1=new excel_opr();
	e1.read_excel1();
	}

}
