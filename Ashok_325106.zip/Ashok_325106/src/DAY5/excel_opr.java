package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class excel_opr {
	
	public Student read_excel(int row)
	{
		Student s=new Student();
		try {
			File f=new File("D:\\training\\Book1.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r=sh.getRow(row);	 
			XSSFCell c=r.getCell(0);
			s.rollno=(int)c.getNumericCellValue();
			XSSFCell c1=r.getCell(1);
			s.name=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			s.m1=(int) c2.getNumericCellValue();
			XSSFCell c3=r.getCell(3);
			s.m2=(int) c3.getNumericCellValue();
			wb.close();
		
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return s;
	}
	public void write_excel(Student s1,int row)
	{
		try {
			File f=new File("D:\\training\\Book1.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(4);
		c.setCellValue((double)s1.avg);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		wb.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

}
