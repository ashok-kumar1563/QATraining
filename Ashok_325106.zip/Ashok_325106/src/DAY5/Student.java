package DAY5;

public class Student {
	int rollno;
	int m1;
	int m2;
	String name;
	float avg;
	public void average()
	{
		this.avg=(this.m1+this.m2)/2.0f;
	}
	public Student()
	{
		this.average();
	}

}
