package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm2 {

	public static void main(String[] args) {
		
		try {
			File f=new File("D:\\training\\Book1.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			//XSSFRow r=sh.getRow(0);
			//XSSFCell c=r.getCell(0);
			//String s=c.getStringCellValue();
			XSSFRow r=sh.createRow(3);
			XSSFCell c1=r.createCell(0);
			//System.out.println(s);
			c1.setCellValue("Selenium");
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
