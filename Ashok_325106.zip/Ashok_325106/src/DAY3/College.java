package DAY3;

public class College {
	public static void main(String arg[])
	{
		Student Rakesh=new Student();
		Rakesh.rollno=73;
		Rakesh.name="Rakesh";
		Rakesh.m1=83;
		Rakesh.m2=91;
		Rakesh.average();
		System.out.println(Rakesh.avg);
		Student priya =new Student();
		priya.rollno=52;
		priya.name="Priya";
		priya.m1=67;
		priya.m2=87;
		priya.average();
		System.out.println(priya.avg);
	}

}
