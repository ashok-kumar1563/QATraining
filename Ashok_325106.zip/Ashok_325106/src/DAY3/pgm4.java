package DAY3;

public class pgm4 {
	static int max(int arr[],int n)
	{
		int max=arr[0];
		for(int i=1;i<n;i++)
		{
			if(max<arr[i])
				max=arr[i];
		}
		return max;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int marks[][]= {{77,95,53,88},{65,92,79,45},{67,54,87,37}};
    for(int i=0;i<3;i++)
    {
    	for(int j=0;j<4;j++)
    	{
    		System.out.print(marks[i][j]+" ");
    	}
    	System.out.println();
    }
for(int i=0;i<3;i++)
{
	int maximum=max(marks[i],4);
	System.out.println("row-"+i+" "+maximum);
}
	
	
	}

}
