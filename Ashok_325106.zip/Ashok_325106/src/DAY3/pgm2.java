package DAY3;

public class pgm2 {
	static boolean isEven(int num)
	{
		if(num%2==0)
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		int num[]= {21,34,91,59,16,25,29,74,49,82};
		int sum=0;
		for(int i=0;i<=9;i++)
		{
			if(isEven(num[i]))
			sum=sum+num[i];
		}
         System.out.println(sum);
         
         
	}

}
