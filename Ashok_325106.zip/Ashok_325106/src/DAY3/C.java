package DAY3;

public class C {

	public static void main(String arg[])
	{
	
	B b1=new B();
	b1.xyz=10;
    b1.abc=20;
	b1.show1();
	b1.show2();
}
}
