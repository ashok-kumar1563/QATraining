package assignment2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		int arr[]= {23,44,84,37,91,18};
		int sum=0;
		for(int i=0;i<=5;i++)
		{
			if(i%2==0&&arr[i]%2!=0)
				sum=sum+arr[i];
		}
		System.out.println(sum);
	}

}
