package assignment2;

public class Bird {
  int No_of_legs;
  int No_of_wings;
  int No_of_tails;
  String Colour;
  String name;
 public void fly()
 {
	 System.out.println("All birds fly");
 }
public void breathe()
{
System.out.println("All birds breathe");	

}
 
	
	
}
