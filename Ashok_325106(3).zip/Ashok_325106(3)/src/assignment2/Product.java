package assignment2;

public class Product {

	int p_id;
	String p_name;
	int per_unit_rate;
	int units_purchased;
	int price;
	String p_grade;
}
