package assignment2;

public class Parrot extends Bird {

	int beak_length;
	void imitate()
	{
		System.out.println("Parrot imitate human");
	}
	void parrot_habitat()
	{
		System.out.println("parrots are found in warm climate all aver most of the world.The greatest diversities exist in austrailia ,central america and south america");
	}
	void parrot_food()
	{
		System.out.println("Most parrot eat fruit flowers,flowers,nuts,seed,and some small creature like insects");
		
	}
	
	public Parrot(String name,String Colour,int No_of_tails,int No_of_legs,int No_of_wings,int beak_length)
	{
	
		this.name=name;
		this.Colour=Colour;
		this.No_of_legs=No_of_legs;
		this.No_of_tails=No_of_tails;
		this.No_of_wings=No_of_wings;
		this.beak_length=beak_length;
		
		
		
		
	}
	public void display()
	{
		
		System.out.println("Name: "+this.name+" Color: "+this.Colour+" No_of_legs :"+this.No_of_legs+" No_of_tails:"+this.No_of_tails+" No_of_wings: "+this.No_of_wings+" beak_length:"+this.beak_length);
		
		
	}
}
