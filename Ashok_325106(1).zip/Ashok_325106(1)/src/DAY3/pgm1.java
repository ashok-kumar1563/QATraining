package DAY3;

public class pgm1 {

	public static void main(String[] args) {
		int std[]= {77,55,91,79,65,92};
		float avg=0;
		int sum=0;
		for(int i=0;i<6;i++)
			sum=sum+std[i];
		avg=sum/6;
		System.out.println(avg);

	}

}
