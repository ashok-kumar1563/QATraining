package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		int sum=0;
	for(int i=10;i<=45;i=i+5)
	{sum=sum+i;
	System.out.print(i+" + ");
		
	}
	System.out.print("50");
	sum=sum+50;
	System.out.println(" = "+sum);

		

	}

}
