package DAY1;

public class pgm1 {
	static boolean isPrime(int n)
	{
		boolean  b=true;
		for(int i=2;i<=n/2;i++)
		{
			if(n%i==0)
			{
				b=false;
				return b;
			}
		}
		return b;
	}

	public static void main(String[] args) {
		int i=0,sum=0,num=11;
		while(true)
		{
			if(i>=10)
				break;
			if(isPrime(num))
			{
				i++;
				sum=sum+num;
				System.out.print(num+" ");
			}
		num++;	
		}
	System.out.println(" = "+sum);	
    
	}

}
