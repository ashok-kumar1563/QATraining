package DAY1;
import java.util.*;

public class pgm11 {

	public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the first number");
    int a=sc.nextInt();
    System.out.println("enter the second number");
    int b=sc.nextInt();
    System.out.println("enter the third number");
    int c=sc.nextInt();
    if(a>b)
    {
    	if(a>c)
    		System.out.println("first is greater");
    	else
    		System.out.println("third is greater");
    }
    else if(b>c)
    	System.out.println("Second is greater");
    else
    	System.out.println("third is greater ");
    	
    


	}

}
