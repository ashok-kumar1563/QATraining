package DAY1;
import java.util.*;

public class pgm12 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the marks1 of strudent ");
	float n1=sc.nextFloat();
	System.out.println("enter the marks2 of strudent ");
	float n2=sc.nextFloat();
	System.out.println("enter the marks3 of strudent ");
	float n3=sc.nextFloat();
	double n=(n1+n2+n3)/3;
	System.out.println("Average marks of the student "+n);
	if(n>=60)
		System.out.println("First class ");
	else if(n>=50)
		System.out.println("Second class");
	else if(n>=35)
		System.out.println("Third class ");
	else 
		System.out.println(" Fail");
	
	}

}
