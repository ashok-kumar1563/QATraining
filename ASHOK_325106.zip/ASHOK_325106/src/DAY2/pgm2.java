package DAY2;

import java.util.Scanner;

public class pgm2 {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number ");
		int n= sc.nextInt();
		int rem=0;
		while(n>0)
		{
		rem=n%10;
		switch(rem)
		{
		case 0 :
			 System.out.println("Zero");
			 break;
		case 1:
		    System.out.println("one");
	    	break;
		case 2:
			System.out.println("two");
			break;
		case 3:
			System.out.println("three");
			break;
		case 4:
			System.out.println("four");
			break;
		case 5:
			System.out.println("five");
			break;
		case 6:
			System.out.println("six");
			break;
		case 7:
			System.out.println("seven");
			break;
		case 8:
			System.out.println("eight");
			break;
		case 9:
			System.out.println("nine");
			break;
		}
		n=n/10;
		
		}
		

	}

}
