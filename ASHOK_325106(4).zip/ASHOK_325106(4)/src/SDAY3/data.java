package SDAY3;

public class data {

	String uid,pwd,exp_res,exp_em1,exp_em2,actual_res,actual_em1,actual_em2,status;

	

}
