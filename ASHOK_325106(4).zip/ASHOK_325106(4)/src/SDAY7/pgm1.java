package SDAY7;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {
	WebDriver dr;
 	pgm1(WebDriver dr)
	{
		this.dr=dr;
	}
 public void enter_txt(String xp,String data)
 {
	 dr.findElement(By.xpath(xp)).sendKeys(data);
 }
 public void click(String xp)
 {
	 dr.findElement(By.xpath(xp)).click();
 }
 public void launchChrome(String url)
 {
	 System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	 dr=new ChromeDriver();
	 dr.get(url);
 }
 public void click_rb(String Xp)
 {
	List l= dr.findElements(By.name(Xp));	
	((WebElement)l.get(0)).click();
	 
	 
 }
 public void verify(String xp,String test_data,int r)
 { 
	 excel_operations excel=new excel_operations();
	 String s=dr.findElement(By.xpath(xp)).getText();
	 if(s.equals(test_data))
	 {
		
		 excel.write_excel(r, 6, "Pass");
		 System.out.println("Registration successfull");
	 }
	 else
	 {
		 excel.write_excel(r, 6, "Fail");
		 System.out.println("Registration successfull");
	 }
 }
 public void closechrome()
 {
	 dr.close();
 }
}
