package SDAY11;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {
	public String read_excel(int r,int c)
	{
		String s=null;
		File f = new File("C:\\Users\\ashok.kumar2\\Desktop\\WebElement.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r1=sh.getRow(r);
			XSSFCell c1=r1.getCell(c);
			 s=c1.getStringCellValue();
			wb.close();
		}
		catch(Exception e)
		{}
		return s;
	}
	public void write_excel(int r,int c,String value)
	{
		File f = new File("C:\\Users\\ashok.kumar2\\Desktop\\WebElement.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r1=sh.getRow(r);
			XSSFCell c1=r1.createCell(c);
			 c1.setCellValue(value);
			FileOutputStream fos=new FileOutputStream(f);
			 wb.write(fos);
			wb.close();
		}
		catch(Exception e)
		{}
	}
	public tc_selection read_sh(int r)
	{
		tc_selection tc1=new tc_selection();

		File f = new File("C:\\Users\\ashok.kumar2\\Desktop\\WebElement.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet3");
			XSSFRow r1=sh.getRow(r);
			XSSFCell c1=r1.getCell(0);
			tc1.tcid=c1.getStringCellValue();
			XSSFCell c2=r1.getCell(1);
			tc1.flag=c2.getStringCellValue();
			XSSFCell c3=r1.getCell(2);
			tc1.no_of_steps=(int)c3.getNumericCellValue();
		}
		catch(Exception e)
		{}
		return tc1;
	}
	public int search(String s)
	{
             int find =-1;
		File f = new File("C:\\Users\\ashok.kumar2\\Desktop\\WebElement.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
		   for(int i=1;i<=16;i++)
		   {
			   XSSFRow r=sh.getRow(i);
			   XSSFCell c=r.getCell(0);
			   String s1=c.getStringCellValue();
			   if(s1.equals(s))
			   {
				   find=i;
				   break;
			   }
				   
			   
		   }
		}
		catch(Exception e)
		{}
		return find;
	}

}
