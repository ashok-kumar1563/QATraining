package SDAY11;

import org.openqa.selenium.WebDriver;

public class pgm2 {

public static void main(String[] args) {
String kw,loc,td;
WebDriver dr=null;
pgm1 we=new pgm1 (dr);
excel_operations excel=new excel_operations();
for(int i=1;i<=3;i++)
{	
tc_selection tc=excel.read_sh(i);
if(tc.flag.equals("N"))
{
	continue;
}
else
{	
	int row=excel.search(tc.tcid);
	if(row!=-1)
	{		
	int step=tc.no_of_steps;
for(int r=row;r<=row+step-1;r++) {
kw= excel.read_excel(r,3);
loc=excel.read_excel(r,4);
td=excel.read_excel(r,5);
System.out.println(kw);
System.out.println(loc);

System.out.println(td);
switch(kw)
{
case "launchChrome":
we.launchChrome(td);
break;
case "enter_txt" :
we.enter_txt(loc,td);
break;
case "click_rb" :
we.click_rb(loc);
break;
case "click_btn" :
we.click(loc);
break;
case "verify" :
we.verify(loc,td,r);
break;
case "closechrome" :
we.closechrome();
break;
}
}
}
}
}
}

}
