package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class webdriver_1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		/*dr.findElement(By.id("email")).sendKeys("7376967157");
		dr.findElement(By.id("pass")).sendKeys("12345"); 
		dr.findElement(By.id("u_0_2")).click();*/
		
       dr.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("7376967157");
		dr.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("12345");
		dr.findElement(By.id("loginbutton")).click();
		String s=dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
		if(s.equals("Ashok"))
			System.out.println("Correct");
		else
			System.out.println("Not correct");
	/*	WebElement wel1 =dr.findElement(By.id("day"));
		Select sel1 = new Select(wel1);
		sel1.selectByVisibleText("15");
		WebElement wel2 =dr.findElement(By.id("month"));
		Select sel2 = new Select(wel2);
		sel2.selectByVisibleText("Feb");
		WebElement wel3 =dr.findElement(By.id("year"));
		Select sel3 = new Select(wel3);
		sel3.selectByVisibleText("1997"); */
	/*	String title =dr.getTitle();
		System.out.println("Title :"+title);
		List rb=dr.findElements(By.name("sex"));
		((WebElement) rb.get(0)).click(); */
		
		
	}

}
