package SADY10;

public class keyword_sh {

	public String TC_ID;
	public String step_no;
	public String KeyWord;
	public String XPath;
	public String Test_Data;

}
