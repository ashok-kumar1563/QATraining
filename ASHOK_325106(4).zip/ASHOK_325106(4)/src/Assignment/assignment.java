package Assignment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class assignment {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver wb=new ChromeDriver();
		wb.get("http://demowebshop.tricentis.com/register");
		List lb=wb.findElements(By.name("Gender"));
		((WebElement)lb.get(0)).click();
		wb.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("Ashok");
		wb.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("yadav");
		wb.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("sarthakgoyal@gmail.com");
		wb.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("ashok123");
		wb.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("ashok123");
		wb.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		String s=wb.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
		if(s.equals("Your registration completed"))
			System.out.println("Registration successfull");
		else
			System.out.println("Registration not successfull");
	 String s1=wb.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	 if(s1.equals("sarthakgoyal@gmail.com"))
		 System.out.println("account is verified");
	 else
		 System.out.println("acoount is not correct");
	 wb.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		

	}

}
