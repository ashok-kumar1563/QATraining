package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Kanika {

WebDriver dr;
String fname;
String lname;
String email;
String pass;
String cpass;
@BeforeClass
 public void launchChrome()

{
System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
dr=new ChromeDriver();
dr.get("http://demowebshop.tricentis.com/");

//for clicking on registration
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();

//for printing title
String title=dr.getTitle();
System.out.println(title);

boolean f=dr.getTitle().contains("Register");

if(!f)
{System.out.println("try again:");}
else
{
System.out.println("Registration page open");
}
}
@Test(priority=1)
 public String data(String fname,String lname,String email,String pass,String cpass)
{
this.fname=fname;
this.lname=lname;
this.email=email;
this.pass=pass;
this.cpass=cpass;
return null;

}
 
 @Test(priority=2)
  public String register(String data) {
 dr.findElement(By.xpath("//*[@id=\"gender-female\"]")).click();
 dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(fname);
 dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(lname);
 dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(email);
 
 dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pass);
 dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(cpass);
 dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
 
return data;
 
//SoftAssert sa=new SoftAssert();
//sa.assertEquals(str1, str);
//System.out.println("registration successful");

  }
 
  @DataProvider(name="security")
  public String[][] provide_data() {
 String[][] data= {{"email","id","emailid1@gmail.com","emailid1","emailid1"},
  {"email1","id1","emailid2@gmail.com","emailid2","emailid2"}
    };  
return data;
 
 
  }
 

  @Test(dataProvider="security")
  public void test1(String fname,String lname,String email,String pass,String cpass) {
 System.out.println("Registration:"+fname+" "+lname+" "+email+" "+pass+" "+cpass);
 
 
 String str="emailid1@gmail.com";
 String str1="emailid1@gmail.com";
 
SoftAssert sa=new SoftAssert();
sa.assertEquals(str1, str);
System.out.println("registration successful");
sa.assertAll();
  }
 
}
