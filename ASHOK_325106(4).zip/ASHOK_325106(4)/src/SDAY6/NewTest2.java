package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest2 {
  @Test(priority = 0)
  public void c() {
	  String ar="noida",er="noida";
	  Assert.assertEquals(ar,er);
	  System.out.println("In test c");
  }
  @Test(priority = 1)
  public void b() {
	  String ar="noida",er="noida1";
	  SoftAssert sf=new SoftAssert();
	  sf.assertEquals(ar,er);
	  System.out.println("In test b");
	  sf.assertAll();
  }
  @Test(priority = 2)
  public void a() {
	  String ar="noida",er="noida1";
	  Assert.assertEquals(ar,er);
	  System.out.println("In test a");
  }
}
