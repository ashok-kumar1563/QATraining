package SDAY6;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test(priority = 0)
  public void c() {
	  System.out.println("C");
  }
  @Test(priority = 1)
  public void b() {
	  System.out.println("B");
  }
  @Test(priority = 2)
  public void a() {
	  System.out.println("A");
  }
}
