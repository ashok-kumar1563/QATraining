package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest3 {
	data d1,d2;
  @Test
  public void t1() {
	  d1=new data();
	  d2=new data();
	  d1.uid="ashokyadav1563@gmail.com";
	  d1.pwd="ashok123";
	  d1.exp_res="SUCCESS";
	  d2=login.llogin(d1);
	  Assert.assertEquals(d2.actual_res, d2.exp_res);
	  System.out.println("data_out.act_res1 "+ d2.actual_res);
  }
  @Test
  public void t2() {
	  d1=new data();
	  d2=new data();
	  d1.uid="ashokyadav1563@gmail.com";
	  d1.pwd="ashok12";
	  d1.exp_res="SUCCESS";
	  d1.exp_em1="Login was unsuccessful. Please correct the errors and try again.";
	  d1.exp_em2="The credentials provided are incorrect";
	  
	  d2=login.llogin(d1);
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(d2.actual_res, d2.exp_res);
	  sa.assertAll();
	  System.out.println("data_out.act_res1 "+ d2.actual_res);
  }
  
}
