package SDAY6;

import org.openqa.selenium.WebDriver;

public class pgm2 {

public static void main(String[] args) {
String kw,loc,td;
WebDriver dr=null;
pgm1 we=new pgm1 (dr);
excel_operations excel=new excel_operations();
for(int r=1;r<=4;r++) {
kw= excel.read_excel(r,1);
loc=excel.read_excel(r,2);
td=excel.read_excel(r,3);
System.out.println(kw);
System.out.println(loc);

System.out.println(td);
switch(kw)
{
case "launchchrome":
we.launchChrome(td);
break;

case "enter_txt" :
we.enter_txt(loc,td);
break;
case "click_btn" :
we.click(loc);
break;
}
}
}

}
