package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {
	public String read_excel(int r,int c)
	{
		String s=null;
		File f = new File("C:\\Users\\ashok.kumar2\\Desktop\\WebElement.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r1=sh.getRow(r);
			XSSFCell c1=r1.getCell(c);
			 s=c1.getStringCellValue();
			wb.close();
		}
		catch(Exception e)
		{}
		return s;
	}

}
