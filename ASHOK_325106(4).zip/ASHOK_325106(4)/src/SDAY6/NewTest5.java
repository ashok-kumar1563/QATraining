package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest5 {
	Basic_Login loginobj;
	data ldata,ldata_out;
	@BeforeClass
	public void config()
	{
		ldata=new data();
		ldata_out=new data();
		loginobj=new Basic_Login();
		
	}
  @Test(dataProvider = "security")
  public void login_test1(String u,String p,String exp_res) {
	  System.out.println("login  "+ u+" "+ p);
	  ldata.uid=u;
	  ldata.pwd=p;
	  
	  ldata.exp_res=exp_res;
	  ldata_out=loginobj.llogin(ldata);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ldata.actual_res, ldata.exp_res);
	  sa.assertAll();
	   }
  @DataProvider(name="security")
  public String[][] getdata()
  {
	  String [][] data= {{"ashokyadav1563@gmail.com","ashok123","SUCCESS" },
	                     {"ashokyadav1563@gmail.com","ashok12","FAILURE"}};
	  return data;
  }
}
