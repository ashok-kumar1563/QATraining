package SDAY2;

public class login_data {
String uid,pwd,exp_res,act_res,test_res;
}
