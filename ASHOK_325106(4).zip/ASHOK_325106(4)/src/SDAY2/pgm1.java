package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		/*dr.findElement(By.id("email")).sendKeys("7376967157");
		dr.findElement(By.id("pass")).sendKeys("12345"); 
		dr.findElement(By.id("u_0_2")).click();*/
		
       dr.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("7376967157");
		dr.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("12345");
		dr.findElement(By.id("loginbutton")).click();
	
		
	}

}
