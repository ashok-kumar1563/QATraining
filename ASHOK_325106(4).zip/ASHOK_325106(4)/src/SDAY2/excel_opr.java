package SDAY2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class excel_opr {
	static login_data d=new login_data();
	public static login_data read__excel()
	{
		File f=new File("Book1.xlsx");
		try {
			 
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c1=r.getCell(0);
			d.uid=c1.getStringCellValue();
			XSSFCell c2=r.getCell(1);
			d.pwd=c2.getStringCellValue();
			XSSFCell c3=r.getCell(2);
			d.exp_res=c3.getStringCellValue();
			
			
		
			
	     	}
    catch(Exception e)
		{}
		System.out.println(d.pwd);
		System.out.println(d.exp_res);
		return d;
		
	}
	public static void login()
	{

		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(d.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(d.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		if(s.equals(d.uid))
		{
			System.out.println("Login successfull");
			d.act_res="pass";
			d.test_res="pass";
		}
		else
		{
			System.out.println("Login not successfull");
			d.act_res="Fail";
			d.test_res="Fail";
			
		}
		
	}
	public static void write_excel()
	{
		File f=new File("Book1.xlsx");
		try {
			login_data d=new login_data();
			d=read__excel();
			 
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c1=r.createCell(3);
			c1.setCellValue(d.act_res);
			XSSFCell c2=r.createCell(4);
			c2.setCellValue(d.test_res);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		} 
		catch(Exception e)
		{}
	}
	
	public static void main(String[] args) {
		read__excel();
		login();
		write_excel();

	}

}
