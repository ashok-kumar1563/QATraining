package SDAY2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm6 {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
	}

}
