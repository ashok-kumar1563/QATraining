package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.w3schools.com/html/html_tables.asp");
		/*String str=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[1]")).getText();
      System.out.println(str);*/
   /*   for(int i=1;i<=3;i++)
      {
    	  String str1=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th["+ i +"]")).getText();
      System.out.print(str1+"                         ");
      }
      System.out.println(); */
      for(int i=2;i<=7;i++)
      {
      for(int j=1;j<=3;j++)
      {
    	  String str1=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+i+"]/td["+ j +"]")).getText();
      System.out.print(str1+"                         ");
      }
      System.out.println();
      }
	}

}
