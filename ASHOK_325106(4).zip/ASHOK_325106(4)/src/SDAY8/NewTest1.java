package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest1 {
	login_page lp;
	home_page hp ;
	WebDriver dr;
	Cart_page cp;
	@BeforeClass
	public void bc()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lp=new login_page(dr);
		hp=new home_page(dr);
		cp=new Cart_page(dr);
	}
  @Test
  public void t1() {
	  lp.do_login("standard_user", "secret_sauce");
	  hp.add_to_cart(1);
	  hp.click_cart();
	  String actual_name= cp.get_prod_name(1);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(actual_name,"Sauce Labs Backpack");
	  sa.assertAll();
	  
	  
  }
}
