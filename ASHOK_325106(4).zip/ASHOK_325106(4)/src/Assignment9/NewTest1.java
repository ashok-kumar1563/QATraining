package Assignment9;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest1 {
	WebDriver dr;
  public String register(String first_name,String last_name,String email,String password,String confirm_password)
  {

		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/register");
	  List l=dr.findElements(By.name("Gender"));
	 ((WebElement)l.get(0)).click();
	 dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(first_name);
	 dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(last_name);
	 dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(email);
	 dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(password);
	 dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(confirm_password);
	dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
	try {
		Thread.sleep(3000);
	}
	catch(Exception e)
	{}
String str=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
/*if(str.equals(email))
	System.out.println("expected email"+ email +" actual email "+str);
else
	System.out.println("incorrect account");*/
  dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
  return str;
	 
  }
  @Test(dataProvider="security")
  public void test1(String first_name,String last_name,String email,String password,String confirm_password)
  {
	  String actual_result=register(first_name,last_name,email,password,confirm_password);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(actual_result, email);
	  sa.assertAll();
	  System.out.println("Expected_result  : "+email+ " "
	  		+ " \nacutual result : "+actual_result);
			  
  }
  @DataProvider(name="security")
  public String[][] getData()
  
  { 
	  String data[][]= {{ "Ashok","kumar","anmolsrivastava123@gmail.com","123456","123456"},
	  {"mahendra","yadav","mahendrayadav@gmail.com","123456","123456"}
			  
	  };
	  return data;
	  
	  
  }
  
}
