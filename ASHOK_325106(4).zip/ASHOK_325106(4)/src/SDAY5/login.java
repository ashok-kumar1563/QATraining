package SDAY5;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {

	public static data llogin(data d) {
 
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.name("Email")).sendKeys(d.uid);
		dr.findElement(By.name("Password")).sendKeys(d.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		boolean f=dr.getTitle().contains("Login");
		if(!f) {
			d.actual_res="Pass";
			System.out.println("Login Successfull");
			d.status="PASS";
		}
		else {
			d.actual_res="FAILURE";
			d.actual_em1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			d.actual_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			System.out.println(d.exp_em1+"\n"+d.exp_em2);
		
		}
		if(d.exp_res.equals("FAILURE")) {
			if(d.actual_em1.equals(d.exp_em1)&&d.actual_em2.equals(d.exp_em2)) {
					d.status="PASS";
				
			}
			else
				d.status="FAILURE";
		}
		
	
return d;
	}


}
