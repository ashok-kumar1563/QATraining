package SDAY5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest4 {
	
	@BeforeMethod
	public void bm()
	{
		System.out.println("Hello");
	}

	@AfterMethod
	public void am()
	{
		System.out.println("Bye");
	}
	@BeforeClass
	public void bc()
	{
		System.out.println("I came to the stadium");
	}
	@AfterClass
	public void ac()
	{
		System.out.println("Now i am back home");
	}
  @Test
  public void t1() {
	  System.out.println("I met Mr. Dhoni");
  }
  @Test
  public void t2() {
	  System.out.println("I had my lunch with Mr. Virat Kohli");
  }
  @Test
  public void t3() {
	  System.out.println("I took a pic with Mr.Rohit sharma");
  }
}
