package SDAY5;

import org.testng.annotations.Test;

public class NewTest3 {
	data d1,d2;
	login l;
  @Test
  public void t1() {
	  d1=new data();
	  d2=new data();
	  l=new login();
	  d1.uid="ashokyadav1563@gmail.com";
	  d1.pwd="ashok123";
	  d1.exp_res="PASS";
	  
	  d2=l.llogin(d1);
	  System.out.println("data_out.act_res1 "+ d2.actual_res);
  }
  
}
