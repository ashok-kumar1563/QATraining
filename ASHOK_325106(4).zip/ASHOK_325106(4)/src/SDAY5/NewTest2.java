package SDAY5;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest2 {
	
	@AfterMethod
	public void AM()
	{
		System.out.println("AM");
	}
	@BeforeMethod
	public void BM()
	{
		System.out.println("BM");
	}
  
  public void t1() {
	  System.out.println("int test t1");
	  
	  
	  
  }
  @Test
  public void t2() {
	  System.out.println("int test t2");
	  
	  
	  
  }
  @Test
  public void t3() {
	  System.out.println("int test t3");
	  
	  
	  
  }
  
}
